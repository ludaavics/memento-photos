## Version 1.0.0 (04 apr 2020)
- Initial template
- Hugo version 0.62.2
- Bootstrap version 4.4.1