---
title: "You’re here because your Wanna Hear Always Good News"
image: "images/about.png"
# description
description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ne  ullamcorper venenatis fringilla. 
Pretium, purus eu nec vulputate vel habitant egestas. Congue ornare at ipsum, viverra. Vitae magna faucibus eros, lectus rhoncus elementum vel. Quis nec viverra lectus augue praesent volutpat"
draft: false

# team
team:
  # team member
  - name : "Bessie Mccoy"
    image : "images/team/1.png"
    designation : "Founder & CEO"
  # team member
  - name : "Juanita Hawkins"
    image : "images/team/2.png"
    designation : "Founder & CEO"
  # team member
  - name : "Arlene Bell"
    image : "images/team/3.png"
    designation : "Founder & CEO"
  # team member
  - name : "Jorge Russell"
    image : "images/team/4.png"
    designation : "Founder & CEO"
---

**A wise girls knows her limit to touch the sky.Repellat sapiente neque praesentium adipisci.The question gave me an idea, so I answered quickly.**

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vel pharetra fringilla nec facilisi. Pharetra id commodo, eget a varius a. Lacus eget proin nunc, arcu lacus scelerisque blandit. Tristique vivamus porta metus, congue viverra amet dignissim scelerisque. Accumsan ut suscipit vel nisl. Est velit vitae augue interdum. Amet amet ullamcorper aliquam sed elementum senectus. Augue convallis ipsum morbi ultricies luctus. Tempor id tellus dui faucibus nunc, turpis platea sit turpis.
Dictum massa vitae sed at morbi. Non condimentum libero augue quam. Nisl at integer gravida sagittis phasellus id elit faucibus viverra. At risus fermentum, suspendisse eu. Viverra ipsum commodo ut eget faucibus sed mi lorem nulla. Sagittis semper elit pharetra, diam pharetra odio fermentum orci vestibulum. Sed eget mi dolor id netus bibendum. Lorem maecenas donec turpis nulla nibh mauris mattis in nisl. Mi lobortis ultrices ut neque. Tellus vitae et faucibus pharetra nec odio. Quam dapibus nascetur tempus odio leo ornare. Malesuada dignissim sodales mauris sit eu donec viverra diam. Sit cras velit blandit eget. Feugiat pharetra dis malesuada massa diam nec.
Rhoncus tortor facilisi pellentesque maecenas id sollicitudin. Tempor blandit cras orci eu tempor volutpat. Velit, ipsum cursus sed sit ac integer odio. Suspendisse donec tellus ullamcorper aliquam viverra tincidunt commodo mauris sit. Odio vivamus tincidunt mauris cras. Curabitur tempus ultricies urna, proin. Ac et.